let IsEmpty = false

function timestampToTime(timestamp) {
    const date = new Date(timestamp*1000);
    const year = date.getFullYear();
    const month = ('0' + (date.getMonth() + 1)).slice(-2);
    const day = ('0' + date.getDate()).slice(-2);
    const hours = ('0' + date.getHours()).slice(-2);
    const minutes = ('0' + date.getMinutes()).slice(-2);
    const seconds = ('0' + date.getSeconds()).slice(-2);
    return `${year}-${month}-${day} ${hours}:${minutes}:${seconds}`;
}

function countOnlineTime(time){
    let hours = Math.floor(time / 3600);
    let minutes = Math.floor((time % 3600) / 60);
    return hours+' 小时' +minutes+' 分钟'
}

function ajaxNotify(url,message,type){
    setTimeout(function () {
        lightyear.loading('hide');
        if (url!=="" && url!=="#"){
            lightyear.url(url);
        }
        if (message!==""){
            lightyear.notify(message, type, 3000);
        }
    }, 1e3)
}

function onRemove(url,goto,data){
    $(document).on('click', '.ajax-remove', function () {
        $.alert({
            title: '真的要删除吗?',
            content: '<b>这将立即删除且不可恢复!</b><br>请谨慎操作!!!',
            buttons: {
                confirm: {
                    text: '是的',
                    btnClass: 'btn-primary',
                    action: function () {
                        lightyear.loading('show');
                        $.ajax({
                            type: "POST",
                            url: url,
                            data: data,
                            success: function (res) {
                                if (res.status===1) {
                                    ajaxNotify(goto, res.msg, 'success');
                                } else {
                                    ajaxNotify(goto, res.msg, 'danger');
                                }
                            },
                            error: function () {
                                ajaxNotify(goto, '数据错误', 'danger');
                            }
                        });
                    }
                },
                cancel: {
                    text: '取消',
                }
            }
        });
        $(document).off('click', '.ajax-remove');
    });
}

function onSubmit(url,goto,data){
    $(document).on('click','.ajax-submit', function(){
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url: url,
            data: data,
            success: function (res) {
                if (res.status===1) {
                    ajaxNotify(goto, res.msg, 'success');
                }else{
                    ajaxNotify(goto, res.msg, 'danger');
                }
            },
            error:function(){
                ajaxNotify(goto, '数据错误', 'danger');
            }
        });
        $(document).off('click','.ajax-submit');
    });
}

function CheckLandProt(url,id){
    let Prot ="";
    $.ajax({
        type: "POST",
        async: false,
        global: false,
        url: url,
        data: {
            id: id
        },
        success: function (data) {
            console.log(data)
            if (data.status===1){
                console.log(data)
                if (data.data["IntrusionProtection"]===1){
                    Prot = "保护中";
                }else{
                    Prot = "未保护";
                }
            }else{
                Prot = "N/A"
            }
        }
    });
    return Prot
}

function CheckSkinName(url,id){
    let Name ="";
    $.ajax({
        type: "POST",
        async: false,
        global: false,
        url: url,
        data: {
            id: id
        },
        success: function (data) {
            if (data.status===1){
                Name = data.data["Name"];
            }else{
                Name = "N/A"
            }
        }
    });
    return Name
}

function CheckPrefixName(url,id){
    let Name ="";
    $.ajax({
        type: "POST",
        async: false,
        global: false,
        url: url,
        data: {
            id: id
        },
        success: function (data) {
            if (data.status===1){
                Name = data.data["Name"];
            }else{
                Name = "N/A"
            }
        }
    });
    return Name
}

function CheckDinoClass(url,name,types){
    let Name ="";
    $.ajax({
        type: "POST",
        async: false,
        global: false,
        url: url,
        data: {
            name: name,
            types: types
        },
        success: function (data) {
            if (data.status===1){
                Name = data.data["Name"];
            }else{
                Name = "N/A"
            }
        }
    });
    return Name
}

function CheckName(url,Identifier,id){
    let Name = 'N/A'
    $.ajax({
        type: "POST",
        async: false,
        url: url,
        data: {
            id: id
        },
        success: function (data) {
            if (data.status===1){
                Name = data.data[Identifier]
            }
        }
    });
    return Name
}

function DinoEmpty(id){
    let Empty = false
    $.ajax({
        type: "POST",
        url:"/home/dino/get",
        async: false,
        data: {
            id: id
        },
        success: function (res) {
            Empty = res.status === 0;
        }
    });
    return Empty
}

function onClaim(id,url,goto){
    $(document).on('click', '.ajax-onClaim',function(){
        $(document).disabled=true
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url:url,
            data: {
                id: id
            },
            success: function (res){
                if (res.status === 1) {
                    ajaxNotify(goto,res.msg,'success');
                }else{
                    ajaxNotify(goto,res.msg,'danger');
                }
            },
            error:function(){
                ajaxNotify(goto,'数据错误','danger');
            }
        });
        $(document).disabled=false
        $(document).off('click','.ajax-onClaim');
    })
}

function onRecovery(id){
    $(document).on('click', '.ajax-recovery',function(){
        if (DinoEmpty(id)){
            lightyear.loading('show');
            $.ajax({
                type: "POST",
                url:"/home/inv/recovery",
                data: {
                    id: id
                },
                success: function (res) {
                    if (res.status===1) {
                        ajaxNotify("/home/inv/list",res.msg,'success');
                    }else{
                        ajaxNotify("/home/inv/list",res.msg,'danger');
                    }
                },
                error:function(){
                    ajaxNotify("/home/inv/list",'数据错误','danger');
                }
            });
            IsEmpty=false
            $(document).off('click','.ajax-recovery');
        }else{
            $.confirm({
                title: '信息',
                content: '检测到您的游戏当前有龙,是否顶龙上线?',
                buttons: {
                    confirm: {
                        text: '确定',
                        btnClass: 'btn-success',
                        action: function(){
                            lightyear.loading('show');
                            $.ajax({
                                type: "POST",
                                url:"/home/inv/recovery/force",
                                data: {
                                    id: id
                                },
                                success: function (res) {
                                    if (res.status===1) {
                                        ajaxNotify("/home/inv/list",res.msg,'success');
                                    }else{
                                        ajaxNotify("/home/inv/list",res.msg,'danger');
                                    }
                                },
                                error:function(){
                                    ajaxNotify("/home/inv/list",'数据错误','danger');
                                }
                            });
                        }
                    },
                    cancel: {
                        text: '取消',
                        btnClass: 'btn-default',
                        action: function(){
                            $.alert('取消了顶龙上线😂');
                        }
                    }
                }
            });
            IsEmpty=false
            $(document).off('click','.ajax-recovery');
        }
    });
}

function onFastRecovery(id){
    $(document).on('click', '.ajax-fastrecovery',function(){
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url:"/home/inv/recovery/fast",
            data: {
                id: id
            },
            success: function (res) {
                if (res.status===1) {
                    ajaxNotify("/home/inv/list",res.msg,'success');
                }else{
                    ajaxNotify("/home/inv/list",res.msg,'danger');
                }
            },
            error:function(){
                ajaxNotify("/home/inv/list",'数据错误','danger');
            }
        });
        $(document).off('click','.ajax-fastrecovery');
    });
}

function joinTeam(id) {
    $(document).on('click', '.ajax-jointeam', function () {
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url: "/home/team/join",
            data: {
                id: id,
            },
            success: function (res) {
                if (res.status===1) {
                    ajaxNotify("/home/team/index", res.msg, 'success');
                } else {
                    ajaxNotify("/home/team/index", res.msg, 'danger');
                }
            },
            error: function () {
                ajaxNotify("/home/team/index", res.msg, 'danger');
            }
        });
        $(document).off('click', '.ajax-jointeam');
    });
}

function onChallengeDino(value,power){
    let items = value.split(',');
    let dino=''
    items.forEach(function (item,index){
        if (items < 1){
            dino='无限制'
        } else {
            name =CheckDinoClass('/'+power+'/att/class',item)
            dino += name+' '
        }
    });
    return dino
}

function onHandleItems(value, power) {
    if (!value) return '';
    // 恐龙名称获取函数
    const getDinoName = (types, power) => {
        const size = parseFloat(types[2]) || 0;
        const isMini = size <= 0.2;
        const path = isMini ? 'types' : 'class';
        const extraParam = isMini ? 'mini' : undefined;
        return CheckDinoClass(`/${power}/att/${path}`, types[1], extraParam);
    }

    // 定义物品类型映射
    const ITEM_TYPES = {
        'Point': '积分',
        'DragonSoul': '龙魂',
        'Shard': '宝箱碎片',
        'SkinShard': '皮肤碎片',
        'ChestKey': '宝箱钥匙',
        'IntensifyCoin': '强化币',
        'Prefix': '称号',
        'TeleportCount': '传送令',
        'TeleportFixedCount': '定点令'
    };

    const rewardHandlers = {
        'Dino': (types) => {
            const size = types[2] === '0' ? '0.2' : types[2];
            const name = getDinoName({ ...types, size }, power);
            const count = types[3] || '1';
            const days = types[4];

            return days && days !== '0'
                ? `${name}×${count}×${days}天`
                : `${name}×${count}`;
        },

        'Point': (types) => {
            const itemType = ITEM_TYPES[types[1]] || '未知物品';
            const count = types[2] || '1';
            return `${itemType}×${count}`;
        },

        'Skin': (types) => {
            const name = CheckSkinName(`/${power}/shop/skin/get`, types[1]);
            const days = types[2] || '0';
            return `${name}皮肤×${days}天`;
        },

        'Prefix': (types) => {
            const name = CheckPrefixName(`/${power}/shop/prefix/get`, types[1]);
            const days = types[2] || '0';
            return `${name}称号×${days}天`;
        }
    };

    try {
        return value.split(',')
            .map(item => {
                const types = item.trim().split(':');
                const handler = rewardHandlers[types[0]];
                if (!handler) {
                    return '';
                }
                return handler(types);
            })
            .filter(Boolean)  // 移除空字符串
            .join('<br>');
    } catch (error) {
        return '奖励解析错误';
    }
}

function onCleanRank(url,goto,types){
    $(document).on('click', '.ajax-onCleanRank',function(){
        $(document).disabled=true
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url:url,
            data: {
                types: types
            },
            success: function (res){
                if (res.status === 1) {
                    ajaxNotify(goto,res.msg,'success');
                }else{
                    ajaxNotify(goto,res.msg,'danger');
                }
            },
            error:function(){
                ajaxNotify(goto,'数据错误','danger');
            }
        });
        $(document).disabled=false
        $(document).off('click','.ajax-onCleanRank');
    })
}

function onCleanTeamRank(url,goto){
    $(document).on('click', '.ajax-onCleanRank',function(){
        $(document).disabled=true
        lightyear.loading('show');
        $.ajax({
            type: "POST",
            url:url,
            success: function (res){
                if (res.status === 1) {
                    ajaxNotify(goto,res.msg,'success');
                }else{
                    ajaxNotify(goto,res.msg,'danger');
                }
            },
            error:function(){
                ajaxNotify(goto,'数据错误','danger');
            }
        });
        $(document).disabled=false
        $(document).off('click','.ajax-onCleanRank');
    })
}

function SkinUse(id) {
    $(document).on('click', '.ajax-skin-use', function () {
        $.alert({
            title: '嗨',
            content: '确定要应用此皮肤到游戏吗?',
            buttons: {
                confirm: {
                    text: '是的',
                    btnClass: 'btn-primary',
                    action: function () {
                        lightyear.loading('show');
                        $.ajax({
                            type: "POST",
                            url:"/home/shop/skin/use",
                            data:{
                                id:id,
                            },
                            success: function (res) {
                                if (res.status===1) {
                                    ajaxNotify("/home/shop/skin/order", res.msg, 'success');
                                } else {
                                    ajaxNotify("/home/shop/skin/order", res.msg, 'danger');
                                }
                            },
                            error: function () {
                                ajaxNotify("/home/shop/skin/order", '数据错误', 'danger');
                            }
                        });
                    }
                },
                cancel: {
                    text: '取消',
                }
            }
        });
        $(document).off('click', '.ajax-skin-use');
    });
}

function SkinRelieve(id) {
    $(document).on('click', '.ajax-skin-relieve', function () {
        $.alert({
            title: '嗨',
            content: '确定要取消应用此皮肤吗?',
            buttons: {
                confirm: {
                    text: '是的',
                    btnClass: 'btn-primary',
                    action: function () {
                        lightyear.loading('show');
                        $.ajax({
                            type: "POST",
                            url:"/home/shop/skin/unuse",
                            data:{
                                id:id,
                            },
                            success: function (res) {
                                if (res.status===1) {
                                    ajaxNotify("/home/shop/skin/order", res.msg, 'success');
                                } else {
                                    ajaxNotify("/home/shop/skin/order", res.msg, 'danger');
                                }
                            },
                            error: function () {
                                ajaxNotify("/home/shop/skin/order", '数据错误', 'danger');
                            }
                        });
                    }
                },
                cancel: {
                    text: '取消',
                }
            }
        });
        $(document).off('click', '.ajax-skin-relieve');
    });
}